wbggrb
wbrgrr
wbgwrg
wrgwbr

