main(){for(;;);}
